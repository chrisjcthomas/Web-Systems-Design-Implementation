<?php
	
	echo "<ul>
  <li><a href='#'>Home</a></li>
  <li><a href='#'>News</a></li>
  <li><a href='showregister.php'>Users</a></li>
  <li><a href= 'form.php'>Register</a></li>
</ul>";
	
?>