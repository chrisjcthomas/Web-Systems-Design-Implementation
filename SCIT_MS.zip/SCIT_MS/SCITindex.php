<!-- SCITindex.php -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>SCIT Management System</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
		<center>
        <h1>Welcome to the SCIT Management System</h1>
        <p>Please <a href="SCITlogin.php">Login</a> to manage student records.</p>
		</center>
    </div>
</body>
</html>
